"""Organize the calibration data we have available."""

import pathlib
from enum import Enum


def get_calibration_path():
    """Return the absolute path to the calibration files in the module."""
    return pathlib.Path(__file__).parent


class CalibrationData(Enum):
    """Contains a list of the calibration files store in the module."""

    mpq_atto_reso_marco = "MPQ_Atto_Reso_Spectrometer_Marco.npz"
    mpq_atto_maya_1184_1101nm = "MPQ_Atto_Maya_184_1101nm.npz"
    mpq_atto_frog_ocean_hdx_xr = "MPQ_Atto_FROG_Ocean_HDX-XR.npz"


class CalibrationLampReferences(Enum):
    """Contains a list of the calibration lamp references stored in the module."""

    mpq_atto_deuterium_halogen = "7315273LS-Deuterium-Halogen_CC-VISNIR.lmp"
    mpq_atto_halogen = "7315273LS-Halogen_CC-VISNIR.lmp"
